package com.delaroystudios.volleyapplication;

/**
 * Created by ahmad-mobile on 04/06/2017.
 */

public class Constans {
    public static final String URL = "http://192.168.8.101/api/ApiBerita/get_berita";
    public static final String URL_GAMBAR = "http://192.168.8.101/api/images/small_";
}
